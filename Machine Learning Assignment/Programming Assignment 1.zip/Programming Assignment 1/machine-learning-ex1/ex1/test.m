close all; clear all; clc

1 - binocdf(11,15,0.5)