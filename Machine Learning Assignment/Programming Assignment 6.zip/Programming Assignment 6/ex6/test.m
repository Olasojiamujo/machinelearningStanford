dataset3Params(X, y, Xval, yval)

